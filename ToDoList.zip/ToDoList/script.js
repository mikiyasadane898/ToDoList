document.addEventListener('DOMContentLoaded', function() {
    const todoInput = document.getElementById('todo-input');
    const addBtn = document.getElementById('add-btn');
    const todoList = document.getElementById('todo-list');

    // Load saved todos from localStorage
    loadTodos();

    // Add new todo
    addBtn.addEventListener('click', function() {
        const todoText = todoInput.value.trim();
        if (todoText !== "") {
            addTodo(todoText);
            saveTodoToStorage(todoText);
            todoInput.value = "";
        }else{
            alert("Pleae Add a new task");
        }
    });

    // Add todo to the list
    function addTodo(text) {
        const li = document.createElement('li');
        const span = document.createElement('span');
        span.textContent = text;
        li.appendChild(span);

        const editBtn = document.createElement('button');
        editBtn.textContent = 'Edit';
        editBtn.className = 'edit-btn';
        li.appendChild(editBtn);

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.className = 'delete-btn';
        li.appendChild(deleteBtn);

        todoList.appendChild(li);

        // Edit todo
        editBtn.addEventListener('click', function() {
            const newText = prompt('Edit your task', span.textContent);
            if (newText !== null) {
                span.textContent = newText.trim();
                updateTodoInStorage(text, newText.trim());
            }
        });

        // Delete todo
        deleteBtn.addEventListener('click', function() {
            todoList.removeChild(li);
            deleteTodoFromStorage(text);
        });
    }

    // Load todos from localStorage
    function loadTodos() {
        const todos = JSON.parse(localStorage.getItem('todos')) || [];
        todos.forEach(todo => {
            addTodo(todo);
        });
    }

    // Save todo to localStorage
    function saveTodoToStorage(todo) {
        const todos = JSON.parse(localStorage.getItem('todos')) || [];
        todos.push(todo);
        localStorage.setItem('todos', JSON.stringify(todos));
    }

    // Update todo in localStorage
    function updateTodoInStorage(oldText, newText) {
        const todos = JSON.parse(localStorage.getItem('todos')) || [];
        const index = todos.indexOf(oldText);
        if (index !== -1) {
            todos[index] = newText;
            localStorage.setItem('todos', JSON.stringify(todos));
        }
    }

    // Delete todo from localStorage
    function deleteTodoFromStorage(todo) {
        const todos = JSON.parse(localStorage.getItem('todos')) || [];
        const index = todos.indexOf(todo);
        if (index !== -1) {
            todos.splice(index, 1);
            localStorage.setItem('todos', JSON.stringify(todos));
        }
    }
});
